# Estudo comparativo MTP — FreeToken vs LTO (somente leitura)

Data: 2026-09-22 · GPU: RTX 5080 16 GB · Modelo: `Qwen3.8-Flash-Next-Unsloth-IQ4_XS/UD-IQ4_XS` + `MTP/mtp-Qwen3.8-Flash-Next-shared-Q8_0.gguf` (os dois motores carregam o mesmo arquivo MTP).
Harness: 16K ctx, prompt 4096, 256 tokens decode, greedy, `--kv-format=turbo3`, `--max-running-requests 1`. Nenhum código-fonte foi alterado.

## 0. Medições desta sessão (FreeToken, commit `0329412`)

| Execução | TG (tok/s) | ms/token | Observação |
|---|---|---|---|
| k=0, CUDA graph, overlap ligado | 35.36 | 28.3 | referência |
| k=0, CUDA graph, overlap desligado | 35.08 | 28.5 | MTP exige overlap desligado; custo do overlap ≈ 0.2 ms |
| k=0, eager (sem graph) | 28.38 | 35.2 | graph economiza **6.9 ms** por passo de 1 token |
| k=1, `FREETOKEN_DEBUG_SPEC_TIMING=1` | 22.43 | — | 490 ciclos, aceitação **55.5 %** |

Estágios do ciclo k=1 (mediana, n=490):

| Estágio | ms | Frequência |
|---|---|---|
| draft_chain (1 passo MTP) | 3.2 | todo ciclo |
| snapshot + prepare + commit | 0.6 | todo ciclo |
| **verify_forward (2 tokens, eager)** | **59.3** | todo ciclo |
| gdn_replay (1 token, decode) | 15.5 | 44.5 % dos ciclos (rejeição) |

Modelo do ciclo: 3.8 + 59.4 + 0.445 × 15.5 = **70.1 ms** para 1.555 tokens → **22.2 TG** (medido 22.43). O modelo fecha com a medição; ele é usado nas estimativas abaixo.

Divisão por camada (`FREETOKEN_DEBUG_LAYER_TIMING=1`, eager, sync por camada — valores inflados, válidos só como proporção):

| | mixer (GDN/QSA/PLE) | MoE |
|---|---|---|
| decode 1 token, soma 48 camadas | 21.5 ms | 22.4 ms |
| verify 2 tokens, soma 48 camadas (derivado) | 29.2 ms | 30.8 ms |
| custo do 2º token | +7.7 ms | +8.4 ms |

## 1. Por que verify custa ~59 ms e decode ~28 ms

Decomposição dos 31 ms extras (59.3 − 28.3):

| Fonte | ms | Evidência |
|---|---|---|
| Execução eager (sem CUDA graph): overhead de launch Python/kernel | ~7 | eager 35.2 vs graph 28.3 ms, 1 token. Verify roda `phase="prefill"` (`scheduler/spec.py:388`); graph só para decode (`engine/graph.py:207`). Com 2 tokens o overhead é maior, pois o GDN roda em laço por token. |
| 2º token no MoE: mais experts distintos por camada | ~8–12 | +8.4 ms MoE por camada somada. Verify usa o caminho decode do cache (`layers/moe.py:196-205`), mas o 2º token roteia para outros experts. Hipótese (não provada, falta `--moe-collect-stats`): o custo vem de misses no cache de experts, porque o replay de 1 token com experts já quentes custa 15.5 ms, contra 28.3 ms de um decode normal. O replay também roda em fase decode (pode usar graph) e com as linhas PLE quentes, o que explica parte da diferença. |
| 2º token no mixer: GDN em laço sequencial token a token + clones de checkpoint | ~6–8 | `models/qwen4_exp/gdn.py:197-231`: laço `for t in range(total)` com conv decode + `gdn_decode_fla` por token; em cada passo, clona recurrent + conv state de cada camada linear (`gdn.py:229-230`). **Esses clones nunca são usados** (ver pergunta 4). |
| QSA/PLE pelo caminho prefill (`extend_len=2`) | incluído no mixer | `models/qwen4_exp/ple.py:394-434` usa o caminho não-decode quando `is_decode=False`. |
| Sync CPU no fim do verify | <0.5 | `spec.py:394` `copy_done_event.synchronize()` — necessário (aceitação no host). |
| Alocações/snapshots | ~0.6 | `spec.py:315-324`: clone do QSA ring/scratch, PLE, residual ×2, `pool.copy_from`. |

Número de forwards por ciclo k=1: 1 forward MTP (draft, 1 camada) + 1 forward do alvo com 2 tokens (verify) + 1 forward do alvo com 1 token em 44.5 % dos ciclos (replay). **Dominante: verify eager com 2 tokens (59 ms = 85 % do ciclo).**

## 2. Como o LTO faz a verificação MTP

Ciclo (driver: `tools/server/server-context.cpp` + `common/speculative.cpp:2591` `common_speculative_impl_draft_mtp`):

1. **Draft**: k passos do grafo `graph_mtp` (`src/models/qwen4exp.cpp:386`), encadeando o próprio hidden. O draft recebe **todas as streams de hyper-connection** do alvo (`t_embd`/`h_nextn`, `qwen4exp.cpp:~475-485`).
2. **Verify**: **1 único forward do alvo** com k+1 tokens num batch.
3. **Aceitação/correção**: amostragem na CPU (`server-context.cpp:945-982`; backend sampling desligado quando há especulação, `server-context.cpp:11171`) → 1 cópia de logits D2H por ciclo.
4. **Rollback sem replay**: durante o verify, o estado recorrente guarda **um snapshot por token** (`n_rs_seq+1` linhas por sequência, `src/llama-memory-recurrent.cpp:690`; escrita em `src/models/delta-net-base.cpp:559-644`). Na rejeição, `seq_rm` só troca o índice (`set_rs_idx`, `llama-memory-recurrent.cpp:808-820`). **Tokens aceitos não são reprocessados.**
5. **CUDA graph**: o verify é elegível. O graph só é desligado quando `mul_mat_id` precisa de sync, ou seja, batch > `MMVQ_MAX_BATCH_SIZE`=8 (`ggml/src/ggml-cuda/ggml-cuda.cu:2702-2709`, `mmvq.cuh:3`). k+1 ≤ 8 continua dentro do graph.
6. **Experts do MTP**: próprios, `blk.48.ffn_{gate,up,down}_exps` (`qwen4exp.cpp:289-321`, carregados com `flags=0` quando `load_mtp`).

Custo do verify LTO k=1, medido (`lto-k1.log`, 3 repetições): aceitação 85.4–90.3 %, média 1.87 tokens/ciclo, 41.08 TG → ciclo 45.5 ms; menos ~2.5 ms de draft → **verify de 2 tokens ≈ 43 ms**, contra 24.9 ms do decode LTO. Portanto o 2º token custa **~18 ms no LTO e ~31 ms no FreeToken**. O LTO também paga pelo token extra. Ele ganha porque: (a) aceitação alta, (b) verify em graph, (c) zero replay. Aviso: saída k≥2 do LTO não foi certificada (greedy não determinístico); throughput não prova correção.

## 3. Por que a aceitação é 55 % no FreeToken e ~85 % no LTO

**Causa raiz confirmada no código e por comparação de pesos: o bloco MoE do MTP no FreeToken usa os experts da camada 0 do modelo principal, e não os experts próprios do MTP.**

- `models/qwen4_exp/model.py:213-222`: `Qwen4ExpDecoderLayer(..., moe_layer_id=config.first_k_dense_replace)` → o MoE do MTP indexa o cache de offload na camada 0 (comentário em `model.py:91-93`: "shares the target's expert bank").
- `models/qwen4_exp/gguf.py:~812-819` (`iter_gguf_mtp_weights`): pula `ffn_gate_exps/ffn_up_exps/ffn_down_exps` do arquivo MTP.
- O GGUF MTP carregado (`shared-Q8_0`, escolhido em `gguf.py:62`) **contém** `blk.48.ffn_{gate,up,down}_exps` com 512 experts (verificado com `gguf.GGUFReader`). O router do MTP (`ffn_gate_inp` do blk.48) escolhe ids de expert que depois se aplicam aos pesos da camada 0. Resultado: saída do MoE do MTP errada, logo draft pior.
- Comparação de pesos (dequantizados, cosseno): `blk.48.ffn_gate_inp` vs `blk.0.ffn_gate_inp` = −0.002; expert 0 de `ffn_down_exps` blk.48 vs blk.0 = −0.0003; `ffn_gate_exps` = −0.0003 (vs blk.47: 0.0005). Os pesos são independentes: blk.48 não é cópia da camada alvo. Portanto `nextn_shared_target_tensors=True` não significa experts compartilhados: o arquivo não traz embedding nem LM head próprios, e o LTO usa os do alvo (`qwen4exp.cpp:416`, `head_w = ... : model.output`).
- O loader do FreeToken lê o router do blk.48 (só os `*_exps` são pulados). Resultado: router do MTP + experts da camada 0 = combinação sem sentido.
- O LTO usa a mesma GGUF e os experts blk.48 → 87 % em k=1 (medido).

Outros fatores (menor peso, não provados): diferença numérica no verify (0.5–5 %, 2/255 argmax flips, já documentado no STATE) e o gating por confiança (`spec.py:346`).

## 4. Custos no hot path especulativo (FreeToken) e impacto estimado

| Item | Local | Custo/ciclo | Impacto se removido |
|---|---|---|---|
| Replay do alvo na rejeição | `spec.py:447-464` | 15.5 ms × 44.5 % = 6.9 ms | 22.2 → 24.6 TG (a=55 %); 28.7 → 29.3 TG (a=87 %) |
| **Zero-replay desligado à força**: `checkpoints = None` | `spec.py:429` (desde `db07811`) | o verify já calcula e clona checkpoints GDN por token (`gdn.py:229-230`), mas os descarta, e o replay roda mesmo assim | clones desperdiçados ≈ 1 ms + todo o replay |
| Motivo provável do desligamento | — | rollback só do GDN; QSA e PLE também avançam no verify e não têm snapshot por token | reativar exige snapshot por token de QSA e PLE (como o LTO faz no recorrente) |
| `.item()` do draft (confiança + token) | `spec.py:346,351` | 2 syncs, <0.3 ms | desprezível |
| `copy_done_event.synchronize()` + `.tolist()` | `spec.py:394-396`, `462` | necessário | — |
| `torch.tensor` por token no commit | `spec.py:209` | <0.1 ms | desprezível |
| Clones de snapshot (QSA/PLE/residual/linear pool) | `spec.py:315-324,380-383` | ~0.6 ms | +0.2 TG |
| Verify eager (sem graph) | `spec.py:388`, `graph.py:207` | ~7–9 ms | ver pergunta 5 |

Limpeza de scheduler/sync: ganho total < 1 ms/ciclo (< +0.4 TG). **Não é prioridade.**

## 5. Plano ranqueado

Fórmula: TG = (1 + a) / (3.8 ms + verify + (1 − a) × replay). a = aceitação; a = 87 % é o valor medido do LTO em k=1 com o mesmo GGUF MTP.
Ponto crítico: com a = 55 %, o k=1 só empata com k=0 (28.3 ms/token) se o verify for ≤ 33 ms (impossível com 2 tokens, pois 1 token em graph já custa 28.3 ms). Com a = 87 %, o empate exige verify ≤ 49 ms (com zero replay), que é alcançável: o LTO faz 43 ms. **Por isso a aceitação vem primeiro: sem ela, nenhum ganho de verify supera k=0.**

| # | Mudança | Atual → esperado | TG k=1 estimado |
|---|---|---|---|
| 1 | Experts nativos do MTP (blk.48) no lugar de alias da camada 0 | a 55 % → ~87 % | 22.2 → **28.7** (faixa 26–29 se a = 75–87 %) |
| 2 | Verify em CUDA graph (captura de 2 tokens, sem caminho prefill) + remover clones não usados | verify 59.4 → ~49 ms | com #1: 28.7 → **34.1** |
| 3 | Zero-replay completo (snapshot por token de GDN + QSA + PLE; religar `checkpoints`) | replay 15.5 × (1−a) → 0 | com #1+#2: 34.1 → **35.4** (empate com k=0) |
| 4 | Custo do 2º token: GDN verify com kernel multi-token (sem laço Python) + menos misses de experts | 2º token 31 → ~18 ms (paridade LTO) → verify ~46 ms | com #1–#3: 35.4 → **~37.5** (+6 % sobre k=0); k≥2 só depois disso |
| 5 | Limpeza de sync/scheduler | ~0.6 ms | +0.3 TG |

Riscos: #1 acrescenta um banco de 512 experts (~2.6 GB Q8) ao cache de offload; ele precisa passar pelo mesmo offload das outras camadas. Deve ser uma camada extra no cache, sem mexer na lógica do planner. O planejador de VRAM não foi reaberto neste estudo. A aceitação real do k=1 no FreeToken só se mede depois do #1.

| Priority | Root cause | Current cost | Proposed fix | Expected TG gain | Confidence |
|---|---|---|---|---|---|
| 1 | MoE do MTP usa experts da camada 0 (`model.py:221`, experts do blk.48 descartados em `gguf.py`) | aceitação 55 % (vs 87 % LTO k=1) | carregar e usar `blk.48.ffn_*_exps` como banco próprio do MTP | 22.2 → ~28.7 (+6.5) | Alta (bug confirmado no código e nos pesos; magnitude média) |
| 2 | Verify eager via caminho prefill | 59.4 ms (graph economiza ~7–9) | capturar verify de k+1 tokens em CUDA graph; remover clones GDN não usados | +5.4 (após #1) | Média |
| 3 | Replay na rejeição; zero-replay desligado (`spec.py:429`) | 15.5 ms × (1−a) | snapshot por token de GDN+QSA+PLE, rollback por índice (modelo LTO) | +1.3 (após #1–#2); +2.4 sozinho | Alta no custo; média no esforço |
| 4 | 2º token: GDN em laço + misses de experts | 2º token 31 ms (LTO 18) | kernel GDN multi-token; menos misses de experts | +2 (após #1–#3) | Baixa–média (precisa de profiler) |
| 5 | Syncs/snapshots no scheduler | ~0.6 ms | limpeza | +0.3 | Alta (ganho pequeno) |

FIRST IMPLEMENTATION TARGET: carregar os experts próprios do MTP (`blk.48.ffn_{gate,up,down}_exps`) e rotear o MoE do MTP para eles, removendo o alias `moe_layer_id=first_k_dense_replace`.

Por quê primeiro:
1. É um bug de correção confirmado no código, não um ajuste: pesos errados no draft.
2. A aceitação multiplica todas as outras melhorias. Com 55 %, nem um verify perfeito passa de k=0.
3. Maior ganho isolado com maior confiança (+6.5 TG) e mudança local (loader + id da camada MoE).
4. Destrava uma medição real da aceitação, que decide se #2–#4 valem o esforço.
5. Não depende de CUDA graph, planner nem rollback.
